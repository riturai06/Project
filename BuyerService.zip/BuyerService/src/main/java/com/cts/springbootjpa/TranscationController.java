package com.cts.springbootjpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springbootjpa.entity.TransactionHistory;
import com.cts.springbootjpa.service.Iservice;

@RestController
public class TranscationController {
	
	@Autowired
	private Iservice service;
	
	@RequestMapping("/getAll/transactions") public List<TransactionHistory> getAllTransactions() 
    {
		  return service.getAllTransaction(); 
    }
	@RequestMapping(value="/Add/transaction/{ids}",method=RequestMethod.POST)
	public TransactionHistory add(@RequestBody TransactionHistory transactionhistory,@PathVariable("ids") int id) 
	{
		return service.addcartItems(transactionhistory, id);
	}
	@RequestMapping(value="/gettransaction/{ids}",method=RequestMethod.GET)
	public TransactionHistory getTransaction(@PathVariable("ids") int id) 
	{
		return service.getTransaction(id);
	}
	@RequestMapping(value="/update/transaction/{ids}",method=RequestMethod.PUT)
	public TransactionHistory updateTransaction(@RequestBody TransactionHistory transactionhistory ,@PathVariable("ids") int id) 
	{
		return service.updateTransaction(transactionhistory,id);
	}
	

}
