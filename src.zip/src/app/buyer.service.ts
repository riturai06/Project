import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from './api.response';


@Injectable({
  providedIn: 'root'
})
export class BuyerService {
  [x: string]: any;
  
  constructor(private http : HttpClient) { }

  private baseUrl = 'http://localhost:8083/buyer/getAll';
  private baseUrl1 = 'http://localhost:8082/Add/buyer';
  private baseUrl2 = 'http://localhost:8083/getUser/{ids}';
  private baseUrl3 = 'http://localhost:8082/generate-token';


  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.baseUrl3}`, loginPayload);
  }

  
createBuyer(buyer:Object):Observable<any>
{   
  
    
    return this.http.post(`${this.baseUrl1}`,"buyer");
}
}