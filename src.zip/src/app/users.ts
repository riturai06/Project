export class User {
    id: string;
    constructor(public name: string, public age: number, public email: string){
        
    }
}