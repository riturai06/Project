export class ApiResponse {

    status: number;
    message: number;
    result: any;
   token: any;
  }
  
  export class User {

    id: number;
  
  }
  