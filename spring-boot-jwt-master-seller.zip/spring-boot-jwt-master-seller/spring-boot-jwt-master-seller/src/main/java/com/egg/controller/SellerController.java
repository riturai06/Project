package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Seller;
import com.egg.service.Iseller;


@RestController
public class SellerController {
	
	@Autowired
	private Iseller service;
	
	@RequestMapping("/getAll")
	public List<Seller> getAll() 
    {
		  return service.getAll(); 
    } 
	
	@RequestMapping(value="/Add/Seller",method=RequestMethod.POST)
	public Seller addSeller(@RequestBody Seller seller) 
	{
		return service.addSeller(seller);
	}
	
	@RequestMapping(value="/getSeller/{id}" , method=RequestMethod.GET)
	public Seller getSeller(@PathVariable("id") int sellerid) {
		return service.getSeller(sellerid);
	}
	
//	@RequestMapping(value="/update/Seller/{id}",method=RequestMethod.PUT)
//	public Seller updateSeller(@RequestBody Seller seller,@PathVariable("id") int sellerid) 
//	{
//		return service.updateSeller(seller,sellerid);
//	}

}
