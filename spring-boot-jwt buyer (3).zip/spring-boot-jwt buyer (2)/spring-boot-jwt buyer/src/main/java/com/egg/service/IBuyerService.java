package com.egg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.RequestBody;

import com.egg.model.Buyer;




public interface IBuyerService {

	List<Buyer> getAllBuyer();

	

	

	void deleteById(Integer buyerId);

	
	 Buyer updateBuyer( Buyer buyer);
	Buyer createBuyer(Buyer buyer);
	Buyer getBuyerByName(String buyerName); 

}
