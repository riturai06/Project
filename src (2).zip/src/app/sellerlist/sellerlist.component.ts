import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellerlist',
  templateUrl: './sellerlist.component.html',
  styleUrls: ['./sellerlist.component.css']
})
export class SellerlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
