import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart } from './cart';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  [x: string]: any;

  private baseUrl = 'http://localhost:8087/search';
  private baseUrl1 = 'http://localhost:8082/DeleteItem';
  private baseUrl2 = 'http://localhost:8082/Add/buyer';
 /* private baseUrl3 = 'http://localhost:8087/Add/seller';*/




  constructor(private http: HttpClient) { }

  getItems(itemname: string) : Observable<any> {
    console.log(name);

    return this.http.get(`${this.baseUrl}/${name}`);
  }
  addToCart(cart:Cart):Observable<any> {
return this.http.post(`http://localhost:8082/Add/items/1`,cart);


  }

displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:8082/getAll/items`);

}

deleteCartItem(cartItemId:number):Observable<any>{
  return this.http.delete(`${this.baseUrl1}/${cartItemId}`);
}

createBuyer(buyer:Object):Observable<any>
{   
  
    
    return this.http.post(`${this.baseUrl2}`,"buyer");
}

createSeller(seller:Object):Observable<Object>
{   
  
    
    return this.http.post(`http://localhost:8087/Add/seller`,seller);
}


}


