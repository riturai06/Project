import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproductlist',
  templateUrl: './addproductlist.component.html',
  styleUrls: ['./addproductlist.component.css']
})
export class AddproductlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
