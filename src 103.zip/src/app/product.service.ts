import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart, ViewCart } from './cart';
import { Transcation } from './transaction';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  [x: string]: any;

  private baseUrl = 'http://localhost:8087/search';
  private baseUrl1 = 'http://localhost:8082/DeleteItem';
  private baseUrl2 = 'http://localhost:8082/Add/buyer';
  private baseUrl3 = 'http://localhost:8082/DeleteAllItem';
  private baseUrl4 ='http://localhost:8082/checkout/1';




  constructor(private http: HttpClient) { }
  addProduct(product: Object): Observable<Object>{

    return this.http.post(`http://localhost:8087/Add/items`,product);
  }
  
  getItems(name: string) : Observable<any> {
    console.log(name);

    return this.http.get(`${this.baseUrl}/${name}`);
  }
  addToCart(cart:Cart):Observable<any> {
return this.http.post(`http://localhost:8082/Add/items/2`,cart);


  }
  
  addItem(product: Object): Observable<Object>{

    return this.http.post(`http://localhost:8087/Add/items`,product);
  }


displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:8082/getAll/items`);

}

deleteCartItem(cartItemId:number):Observable<any>{
  return this.http.delete(`${this.baseUrl1}/${cartItemId}`);
}


createSeller(seller: Object): Observable<Object>{

  return this.http.post(`http://localhost:8087/Add/seller`,seller);
}
createBuyer(buyer: Object): Observable<Object>{

  return this.http.post(`http://localhost:8082/Add/buyer`,buyer);
}
deleteAllItems():Observable<void> {

  return this.http.delete<void>(`${this.baseUrl3}`);
}

CheckoutCart(transcation:Transcation): Observable<any> {
  return this.http.post(`${this.baseUrl4}`,transcation);
  
}

updateCartItems(cartview:ViewCart) : Observable<any>{
  console.log(cartview);
  return this.http.put(`http://localhost:8082/updatecart`,cartview);
}


}


