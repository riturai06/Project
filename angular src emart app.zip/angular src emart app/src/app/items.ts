export class Item {

    itemid:number;
    categoryid:number;
    subcategoryid:number;
    itemCost:number;
    itemName:string;
    itemDescription:string;
    quantity:number;
    model:string;
    manfacture:string;
    sellerid:number;

   
}
