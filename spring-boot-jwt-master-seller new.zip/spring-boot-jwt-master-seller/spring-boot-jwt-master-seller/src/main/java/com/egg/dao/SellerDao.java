package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.Seller;
 

@Repository
public interface SellerDao extends JpaRepository<Seller, Integer> {
	
	
	Seller findByUsername(String username);
//	Seller findOne(int id);

//	Seller findOne(int sellerid);

}
