package com.cts.sprinbootjp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.RequestBody;

import com.cts.sprinbootjp.model.Buyer;
import com.cts.sprinbootjp.model.CartItems;
import com.cts.sprinbootjp.model.PurchaseHistory;
import com.cts.sprinbootjp.model.TransactionHistory;




public interface IBuyerService {

	List<Buyer> getAll();
	Buyer add(Buyer buyerdetails);
	Buyer getUser(int id);
	Buyer updateBuyer(Buyer buyerdetails,int id);
	
	//Items SERVICE
	List<CartItems> getAllItems();
	CartItems addcart(CartItems cartItems,int id);
	CartItems getItem(int id);
	CartItems updateItem(CartItems cartItems,int id);
	void  deleteItem(int id);
	void  deleteAllItem();
	
	
	//Transactions SERVICE
	List<TransactionHistory> getAllTransaction();
	TransactionHistory addcartItems(TransactionHistory transactonhistory,int id);
	TransactionHistory getTransaction(int id);
	TransactionHistory updateTransaction(TransactionHistory transactionhistory,int id);
//	TransactionHistory checkout(TransactionHistory transactionhistory,int id);
	
	
	
	//purchasehistory SERVICE
	List<PurchaseHistory> getPurchase();
	PurchaseHistory addPurchase(PurchaseHistory purchasehistory,int id,int ids);
	PurchaseHistory getpurchase(int id);
	PurchaseHistory updatePurchase(PurchaseHistory purchasehistory,int id);
	
		String checkout(TransactionHistory transactonhistory,int ids);
		Buyer getBuyerByName(String buyerName);
		Buyer updateBuyer(Buyer buyer);
		
	
}
