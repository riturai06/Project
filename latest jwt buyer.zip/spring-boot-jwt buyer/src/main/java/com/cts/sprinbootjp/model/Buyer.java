package com.cts.sprinbootjp.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Buyer implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer buyerId;
	private Long mobileNo;
	private String password;
	private String email;
	private String buyerName;
    private LocalDate date;
	public Integer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Buyer(Integer buyerId, Long mobileNo, String password, String email, String buyerName, LocalDate date) {
		super();
		this.buyerId = buyerId;
		this.mobileNo = mobileNo;
		this.password = password;
		this.email = email;
		this.buyerName = buyerName;
		this.date = date;
	}
	public Buyer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Buyer [buyerId=" + buyerId + ", mobileNo=" + mobileNo + ", password=" + password + ", email=" + email
				+ ", buyerName=" + buyerName + ", date=" + date + "]";
	}
    
	
	
	
	
	
	
	
}
