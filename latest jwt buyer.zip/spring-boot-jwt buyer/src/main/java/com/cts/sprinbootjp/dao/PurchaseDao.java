package com.cts.sprinbootjp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.sprinbootjp.model.PurchaseHistory;


public interface PurchaseDao extends JpaRepository<PurchaseHistory, Integer>{

}
