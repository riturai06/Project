package com.cts.sprinbootjp.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cts.sprinbootjp.dao.IBuyerdao;
import com.cts.sprinbootjp.model.Buyer;
import com.cts.sprinbootjp.service.BuyerServiceImplement;
import com.cts.sprinbootjp.service.IBuyerService;


@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/buyer")
public class BuyerRestController {
	
	@Autowired
	private IBuyerService service;

	//Buyers
    @RequestMapping("/getAll") public List<Buyer> getAll() 
    {
		  return service.getAll(); 
    } 
	@RequestMapping(value="/Add/buyer",method=RequestMethod.POST)
	public Buyer add(@RequestBody Buyer buyerdetails) 
	{
		return service.add(buyerdetails);
	}
	@RequestMapping(value="/getUser/{ids}",method=RequestMethod.GET)
	public Buyer getUser(@PathVariable("ids") int id) 
	{
		return service.getUser(id);
	}
	@RequestMapping(value="/update/buyer/{ids}",method=RequestMethod.PUT)
	public Buyer updateBuyer(@RequestBody Buyer buyerdetails,@PathVariable("ids") int id) 
	{
		return service.updateBuyer(buyerdetails,id);
	}
	

}
