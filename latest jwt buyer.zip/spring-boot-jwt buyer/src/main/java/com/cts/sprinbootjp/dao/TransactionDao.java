package com.cts.sprinbootjp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.sprinbootjp.model.TransactionHistory;


public interface TransactionDao extends JpaRepository<TransactionHistory, Integer>{

	TransactionHistory findOne(int id);

}
