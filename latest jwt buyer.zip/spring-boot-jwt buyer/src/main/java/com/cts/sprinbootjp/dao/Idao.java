package com.cts.sprinbootjp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.sprinbootjp.model.Buyer;



@Repository
public interface Idao extends JpaRepository<Buyer, Integer>{

	Buyer findOne(int id);

}
