import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-addproductdetails',
  templateUrl: './addproductdetails.component.html',
  styleUrls: ['./addproductdetails.component.css']
})
export class AddproductdetailsComponent implements OnInit {

  @Input()

  product:Product;

 constructor(private pSservice:ProductService) { }

 ngOnInit(): void {
 }

}
