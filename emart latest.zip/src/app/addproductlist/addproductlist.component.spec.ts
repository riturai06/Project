import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddproductlistComponent } from './addproductlist.component';

describe('AddproductlistComponent', () => {
  let component: AddproductlistComponent;
  let fixture: ComponentFixture<AddproductlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddproductlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddproductlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
