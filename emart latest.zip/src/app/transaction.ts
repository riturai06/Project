export class Transcation {

    transactionType:string;
    dateTime:string;
    remarks:string;
    price:number;

}
