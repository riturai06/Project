import { Component, OnInit } from '@angular/core';
import { Cart, ViewCart } from '../cart';
import { ProductService } from '../product.service';
import { Item } from '../items';
import { Product } from '../product';
import { Transcation } from '../transaction';



@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {


  disCart:Cart[];
  cartItemId:number;
  cart:Cart;
  j:any;
  cost: number;
  viewcart:ViewCart= new ViewCart();
  success:string;
  transcation:Transcation=new Transcation();
  constructor(private displaycart:ProductService) { }

  ngOnInit(): void {


    this.displaycart.displayCartItems().subscribe( disCart => this.disCart=disCart);
    console.log(this.disCart);
    
  }

  reloadcartItems(){
    this.displaycart.displayCartItems().subscribe(disCart=>{console.log("mark"+JSON.stringify(disCart));
  this.disCart=disCart})
  }

  delete(j){
    console.log("inside delete");
    console.log(j);
    this.displaycart.deleteCartItem(j).subscribe(()=>{console.log("item deleted");
    this.reloadcartItems();},(error)=>console.log(error));
  

  //   this.displaycart.deleteCartItem().subscribe(disCart=>this.disCart=this.disCart);
     
    
   }
    
   incrementQty(cartview:ViewCart){
     this.cost=cartview.price;
      cartview.quantity+=1
      if(cartview.quantity!=1){
        cartview.total=cartview.quantity*this.cost;
        console.log(cartview);
        console.log("Quantity"+cartview.quantity+"\nCartId:"+cartview.cartItemId);
        this.displaycart.updateCartITems(cartview).subscribe(view=>this.viewcart=view); 
      }
      
   }

  decrementQty(cartview:ViewCart){
     this.cost=cartview.price;
     console.log(cartview.price);
      
      if(cartview.quantity!=1){
        cartview.quantity-=1
        cartview.total=cartview.quantity*this.cost;
        console.log(cartview);
        console.log(cartview.quantity,cartview.cartItemId);
        this.displaycart.updateCartItems(cartview).subscribe(view=>this.viewcart=view); 
      }
      
   }

   DeleteAll(){
    this.displaycart.deleteAllItems().subscribe(

    () =>console.log("Delete All Items"),
    (error) =>console.log(error)
          );
  }
 Checkout(transcation:Transcation){
  console.log();
  this.transcation.transactionType="credit card";
  this.transcation.remarks="good";
  this.transcation.dateTime="25-09-2019";
  console.log("entering the method"+transcation);
//  this.displaycart.CheckoutCart(transcation).subscribe(newview => this.viewcart=newview);
 this.displaycart.CheckoutCart(transcation).subscribe(
  () =>{console.log("success"); this.reloadcartItems()},
   (error) => console.log(error));
   window.alert("checkout done successfully!");
 }

   

}
