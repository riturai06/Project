package com.example.demo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transactions {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int tid;
	@Column(name="user_id")
	private int userId;
	@Column(name="seller_id")
	private int sellerId;
	@Column(name="transaction_type")
	private int transactiontype;
	@Column(name="date_time")
	private LocalDate datetime;
	private String remarks;
	public Transactions() {
		
	}
	@Override
	public String toString() {
		return "Transactions [tid=" + tid + ", userId=" + userId + ", sellerId=" + sellerId + ", transactiontype="
				+ transactiontype + ", datetime=" + datetime + ", remarks=" + remarks + "]";
	}
	public Transactions(int tid, int userId, int sellerId, int transactiontype, LocalDate datetime, String remarks) {
		super();
		this.tid = tid;
		this.userId = userId;
		this.sellerId = sellerId;
		this.transactiontype = transactiontype;
		this.datetime = datetime;
		this.remarks = remarks;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public int getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(int transactiontype) {
		this.transactiontype = transactiontype;
	}
	public LocalDate getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDate datetime) {
		this.datetime = datetime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	
}
