package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Category {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int category_id;
	@Column(name="Category_name")
	private  String CategoryName;
	@Column(name="Brief_details")
	private String BriefDetails;

	public Category(int category_id, String categoryName, String briefDetails) {
		super();
		this.category_id = category_id;
		this.CategoryName = categoryName;
		this.BriefDetails = briefDetails;
	}
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", CategoryName=" + CategoryName + ", BriefDetails="
				+ BriefDetails + "]";
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getCategoryName() {
		return CategoryName;
	}
	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}
	public String getBriefDetails() {
		return BriefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		BriefDetails = briefDetails;
	}
	

}
